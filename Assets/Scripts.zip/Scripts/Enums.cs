using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enums : MonoBehaviour
{
    public enum Path
    {
        Path1,
        Path2
    }
    public enum TowerType
    {
        Archer,
        Sword,
        Wizard
    }
    public enum SiteLevel
    {
        Onbebouwd,
        level1,
        level2,
        level3

    }
}

